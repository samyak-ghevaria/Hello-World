class Main 
{
  public static void main(String[] args) 
  {
    System.out.println("Hello world!");
    System.out.println("My name is Samyak Ghevaria");
    System.out.println("I am 16 years old");
    System.out.println("I enjoy playing video games and watching movies");
    System.out.println("I also like playing sports with friends");
    System.out.println("I don't like staying at home all day.");
  }
}